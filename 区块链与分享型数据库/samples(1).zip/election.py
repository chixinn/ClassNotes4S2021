from web3_deploy import *
import random

Trump = w3.toBytes(text="Trump")
Biden = w3.toBytes(text="Biden")
us_election = compile_and_deploy("Ballot", [Trump, Biden])

# give right to vote
print('\nGive right to vote...')
for account in eth.accounts[1:]:
    tx_hash = us_election.functions.giveRightToVote(account).transact()
    tx_receipt = eth.waitForTransactionReceipt(tx_hash)
    print('give right to vote:', account, '\tstatus:', us_election.functions.voters(account).call())

# delegate todo

# vote
print('\nStart vote...')
for account in eth.accounts:
    eth.default_account = account
    weight, voted, delegate, vote = us_election.functions.voters(account).call()
    if weight > 0 and not voted:
        proposal_id = random.choice([0, 1])
        tx_hash = us_election.functions.vote(proposal_id).transact()
        tx_receipt = eth.waitForTransactionReceipt(tx_hash)
        proposal_name, vote_count = us_election.functions.proposals(proposal_id).call()
        print(account, 'vote', proposal_name.decode(), ', current count:', vote_count)

# election done
print('\nElection done!')
eth.default_account = eth.accounts[0]
trump_info = us_election.functions.proposals(0).call()
biden_info = us_election.functions.proposals(1).call()
us_election.functions.winningProposal().transact()
winnerName = us_election.functions.winnerName().call().decode()
print('trump vote count:', trump_info[1])
print('biden vote count:', biden_info[1])
print("US presidential election 2020, the winner is " + winnerName + "!");
