import network.Network;

public class MiniChainApplication {

    public static void main(String[] args) {
        Network netWork = new Network();
        netWork.start();
    }
}
